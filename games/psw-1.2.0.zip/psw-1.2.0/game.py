WIDTH = 30
HEIGHT = 20
TITLE = 'Simple Game'
